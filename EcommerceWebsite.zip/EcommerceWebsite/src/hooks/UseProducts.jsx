// hooks/useProducts.js
import { useState, useEffect, useCallback } from "react";
/**
 * Custom hook to fetch and return all products once.
 * Must be called at top level of a component.
 */

export function useProducts() {
  const [products, setProducts] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchProducts = useCallback(async () => {
    setIsLoading(true); // Ensure loading is true at the start
    setError(null); // Clear any previous errors

    try {
      const res = await fetch("https://dummyjson.com/products");
      if (!res.ok) {
        throw new Error(`HTTP error! status: ${res.status}`);
      }
      const data = await res.json();
      setProducts(data.products);
    } catch (err) {
      console.error("Error fetching products:", err);
      setError(err);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchProducts();
  }, [fetchProducts]);

  return [products, isLoading, error];
}
