import { useState, useEffect, useCallback } from "react";

/**
 * Custom hook to search products by title from a list.
 * @param {Array} products — all available products
 * @param {string} searchTerm — title to match (case-insensitive)
 * @returns {Array} — filtered matching products
 */
export function useSearchProduct(products, searchTerm) {
  const [results, setResults] = useState([]);

  const filterSearch = useCallback(() => {
    if (!searchTerm) {
      setResults([]);
      return;
    }
    const filtered = products.filter(
      (item) => item.title.toLowerCase().includes(searchTerm.toLowerCase()),
    );
    setResults(filtered);
  }, [products, searchTerm]);

  useEffect(() => {
    filterSearch();
  }, [filterSearch]);

  return results;
}