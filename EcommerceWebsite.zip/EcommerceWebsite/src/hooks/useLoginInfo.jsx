// src/hooks/useLoginInfo.js
import { useState, useCallback } from "react";

function useLoginInfo() {
  const [response, setResponse] = useState(null);
  const [error, setError] = useState(null);

  const login = useCallback(async (Username, Password) => {
    if (!Username || !Password) return;

    try {
      const res = await fetch("https://dummyjson.com/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          username: Username,
          password: Password,
          expiresInMins: 30,
        }),
        credentials: "include",
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.message || "Invalid username or password");
      }

      setResponse(data);
      setError(null);
    } catch (err) {
      setError(err.message || "Something went wrong");
      setResponse(null);
    }
  }, []);

  return { response, error, login };
}

export default useLoginInfo;
