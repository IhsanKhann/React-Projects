import React, { useState } from "react";
import { useDispatch } from "react-redux";
import { useProducts } from "../hooks/UseProducts.jsx";
import { RemoveProduct, addProducts } from "../Slices/sliceAdmin.jsx";
import ProductComponent from "../components/productComponent.jsx";
import "./HomeAdmin.css";

function HomeAdmin() {
  const { products, isLoading: loadingProducts, error } = useProducts();
  const [showAddForm, setShowAddForm] = useState(false);
  const dispatch = useDispatch();

  const handleRemove = (item) => {
    dispatch(RemoveProduct(item));
  };

  const handleAddProduct = (newProduct) => {
    dispatch(addProducts(newProduct));
    setShowAddForm(false);
  };

  return (
    <>
      {loadingProducts && <p>Loading products...</p>}

      {error && <p>Error: {error}</p>}

      {products && products.length > 0 ? (
        <div className="products-section">
          {products.map((item) => (
            <div key={item.id} className="product-card">
              <img
                src={item.images?.[0]}
                alt={item.title}
                className="product-image"
              />
              <h2 className="product-title">{item.title}</h2>
              <p className="product-description">{item.description}</p>
              <h4 className="product-category">{item.category}</h4>
              <h4 className="product-price">${item.price}</h4>

              <button onClick={() => handleRemove(item)} className="remove-btn">
                Remove
              </button>
            </div>
          ))}
        </div>
      ) : (
        !loadingProducts && !error && <p>No products available</p>
      )}

      <div>
        <button onClick={() => setShowAddForm(true)} className="add-btn">
          Add Product
        </button>

        {showAddForm && <ProductComponent onAdd={handleAddProduct} />}
      </div>
    </>
  );
}

export default HomeAdmin;