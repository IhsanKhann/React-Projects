// HomeUser.jsx
import React, { useState } from "react";
import { useDispatch } from "react-redux";
import { useProducts } from "../hooks/UseProducts.jsx";
import { useSearchProduct } from "../hooks/useSearchProducts.jsx";
import { addToCart } from "../Slices/sliceCart";
import Sidebar from "../components/Sidebar.jsx";
import "./HomeUser.css";

export default function HomeUser() {
  const { products, isLoading: loadingProducts } = useProducts();
  const dispatch = useDispatch();

  const [searchTerm, setSearchTerm] = useState("");
  const [hasSearched, setHasSearched] = useState(false);

  // ✅ search hook also at top level
  const searchResults = useSearchProduct(products, searchTerm);

  const handleSearch = (e) => {
    e.preventDefault();
    setHasSearched(true);
  };

  const itemsToDisplay = hasSearched ? searchResults : products;
  // everything is array here -> itemsToDisplay is an array of products(useProducts.jsx) or searchResults(fromUseSearchProducts.jsx)
  // new thing learned and very useful.

  const handleAddToCart = (item) => {
    dispatch(addToCart(item));
  };

  return (
    <div className="home-user-container">
      {/* Search-Bar: */}

      <div className="SearchBar">
        <form onSubmit={handleSearch}>
          <input
            type="text"
            placeholder="Search for a product..."
            value={searchTerm}
            onChange={(e) => {
              setSearchTerm(e.target.value);
              // Reset search if user starts typing again
              setHasSearched(false);
            }}
          />
          <button type="submit">Search</button>
        </form>
      </div>

      {loadingProducts && <p>Loading products...</p>}
      {/* this is optional renders when the products are being fetched from the products hook. */}

      {/* The products on the main page  */}
      <div className="products-section">
        {itemsToDisplay && itemsToDisplay.length > 0 ? (
          itemsToDisplay.map((item) => (
            <div key={item.id} className="product-card">
              <img
                src={item.images?.[0]}
                alt={item.title}
                className="product-image"
              />
              <h2 className="product-title">{item.title}</h2>
              <p className="product-description">{item.description}</p>
              <h4 className="product-category">{item.category}</h4>
              <h4 className="product-price">${item.price}</h4>
              <button
                className="add-to-cart-btn"
                onClick={() => handleAddToCart(item)}
              >
                Add to Cart
              </button>
            </div>
          ))
        ) : (
          // in case no products are found..
          <h2>
            {hasSearched
              ? "No matching products found"
              : "No products available"}
          </h2>
        )}
      </div>

      {/* the sidebar. The sidebar is styled at the right */}
      <div className="sidebar-section">
        <Sidebar />
      </div>
    </div>
  );
}

// when searching the hasSearched state is set to true, and the itemsToDisplay state is set to the searchResults state.
// Items to display -> works on the hasSearched state. (if hasSearched is true, then itemsToDisplay is set to searchResults,
// else itemsToDisplay is set to products)