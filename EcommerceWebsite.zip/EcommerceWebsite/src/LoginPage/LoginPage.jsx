import React, { useState } from "react";
import User from "../components/User";
import Admin from "../components/Admin";
import "./LoginPage.css"; // Import CSS for styling

function LoginPage() {
  const [isUser, setIsUser] = useState(false);
  const [hideText, setHideText] = useState(false);

  const handleClick = (e) => {
    setHideText(true);
    const role = e.target.innerText.trim().toLowerCase();
    setIsUser(role === "user");
  };

  return (
    <div className="login-container">
      {hideText ? (
        isUser ? (
          <User />
        ) : (
          <Admin />
        )
      ) : (
        <div className="login-card">
          <h1 className="login-title">Choose Your Role</h1>
          <div className="button-group">
            <button className="login-btn user" onClick={handleClick}>User</button>
            <button className="login-btn admin" onClick={handleClick}>Admin</button>
          </div>
        </div>
      )}
    </div>
  );
}

export default LoginPage;
