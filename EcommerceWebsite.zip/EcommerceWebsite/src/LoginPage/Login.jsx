// Login.jsx
import React, { useState, useEffect } from "react";
import useLoginInfo from "../hooks/useLoginInfo";

/**
 * Login form component.
 * Uses a custom authentication hook for handling login logic.
 */

function Login() {
  const [username, setUsername] = useState(""); // Controlled username state
  const [password, setPassword] = useState(""); // Controlled password state
  const [token, setToken] = useState(localStorage.getItem("token") || ""); // Stored auth token

  const { response, error, login } = useLoginInfo(); // Custom hook for login logic

  // Handles form submission and invokes login()
  const handleSubmit = async (e) => {
    e.preventDefault();
    await login(username, password);
  };

  // When login response changes, save token and greet user
  useEffect(() => {
    if (response?.token) {
      localStorage.setItem("token", response.token);
      setToken(response.token);
      alert(`Welcome ${response.firstName}`);
    }
  }, [response]);

  return (
    <div>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Enter your username"
          value={username}
          required
          onChange={(e) => setUsername(e.target.value)}
        />
        <br />
        <input
          type="password"
          placeholder="Enter your password"
          value={password}
          required
          onChange={(e) => setPassword(e.target.value)}
        />
        <br />
        <button type="submit">Login</button>
      </form>

      {/* Display any login error */}
      {error && <p style={{ color: "red" }}>{error}</p>}

      {/* Welcome or prompt based on token presence.Just for testing presence.*/}
      {token ? (
        <div>
          <h2>Welcome back!</h2>
        </div>
      ) : (
        <div>
          <h2>Please Login</h2>
        </div>
      )}
    </div>
  );
}

export default Login;
