import React, { useEffect } from "react";
import Login from "../LoginPage/Login.jsx";
import HomeAdmin from "../HomePages/HomeAdmin.jsx";

import { useProducts } from "../hooks/UseProducts.jsx";
import { useDispatch } from "react-redux";
import { setProducts } from "../Slices/sliceAdmin.jsx";

function Admin() {
  const [products, isLoading] = useProducts();
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(setProducts(products));
  }, []);

  return (
    <>
      <Login />
      <HomeAdmin />
    </>
  );
}

export default Admin;
