import React from "react";
import HomeUser from "../HomePages/HomeUser";
import Login from "../LoginPage/Login";

function User() {
  return (
    <>
      <Login />
      <HomeUser />
    </>
  );
}

export default User;
