import React, { useState } from "react";
import "./product.css";

function ProductComponent({ onAdd }) {
  // Initialize form state with controlled inputs
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    price: "",
    category: "",
  });

  // Update formData when any input changes
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  // Handle form submission
  const handleSubmit = (e) => {
    e.preventDefault();
    const newProduct = {
      ...formData,
      price: parseFloat(formData.price) || 0,
      id: Date.now(), // generate mock ID
    };
    onAdd(newProduct);
    setFormData({ title: "", description: "", price: "", category: "" });
  };

  return (
    <form onSubmit={handleSubmit} className="add-product-form">
      <input
        name="title"
        placeholder="Title"
        value={formData.title}
        onChange={handleChange}
        required
      />
      <textarea
        name="description"
        placeholder="Description"
        value={formData.description}
        onChange={handleChange}
        required
      />
      <input
        name="price"
        type="number"
        step="0.01"
        placeholder="Price"
        value={formData.price}
        onChange={handleChange}
        required
      />
      <input
        name="category"
        placeholder="Category"
        value={formData.category}
        onChange={handleChange}
        required
      />
      <button type="submit">Save Product</button>
    </form>
  );
}

export default ProductComponent;
