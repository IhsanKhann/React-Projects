import React, { useState, useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import { removeFromCart } from "../Slices/sliceCart"; // ✅ uncommented
import "./Sidebar.css";

function Sidebar() {
  const cart = useSelector((state) => state.cart.cart);
  
  const [checkedItems, setCheckedItems] = useState([]);
  const [total, setTotal] = useState(0);
  
  const dispatch = useDispatch();

  const handleCheckboxChange = (item) => {
    const isChecked = checkedItems.find((i) => i.id === item.id);

    if (isChecked) {
      setCheckedItems((prev) => prev.filter((i) => i.id !== item.id));
    } else {
      setCheckedItems((prev) => [...prev, item]);
    }
  };

  const handleCheckout = () => {
    const totalAmount = checkedItems.reduce(
      (acc, item) => acc + item.price * item.quantity,
      0,
    );
    setTotal(totalAmount);
  };

  const handleClearCart = () => {
    setCheckedItems([]);
    setTotal(0);
  };

  const handleRemoveFromCart = (itemId) => {
    dispatch(removeFromCart(itemId));
    setCheckedItems((prev) => prev.filter((i) => i.id !== itemId)); // optional: uncheck it
  };

  useEffect(() => {
    // Recalculate total whenever checkedItems changes
    const totalAmount = checkedItems.reduce(
      (acc, item) => acc + item.price * item.quantity,
      0,
    );
    setTotal(totalAmount);
  }, [checkedItems]);

  return (
    <div className="sidebar">
      <h2>Your Cart</h2>

      {Array.isArray(cart) && cart.length > 0 ? (
        cart.map((item) => (
          <div className="cart-item" key={item.id}>
          
            <input
              type="checkbox"
              checked={checkedItems.some((i) => i.id === item.id)}
              onChange={() => handleCheckboxChange(item)}
            />
            <div className="item-details">
              <h3>{item.title}</h3>
              <p>{item.description}</p>
              <div className="price-category">
                <span>Quantity: {item.quantity}</span>
                <span className="category">{item.category}</span>
          
                <button onClick={() => handleRemoveFromCart(item.id)}>
                  Remove
                </button>
                
              </div>
            </div>
          </div>
        ))
      ) : (
        <p>No items in the cart</p>
      )}

      {/* Footer -> with the Total Price and Amount */}
      
      <div className="sidebar-footer">
        <h3>Total: ${total.toFixed(2)}</h3>
        <button onClick={handleCheckout}>
          Checkout ({checkedItems.reduce((acc, i) => acc + i.quantity, 0)})
        </button>
        <button className="clear-btn" onClick={handleClearCart}>
          Clear Cart
        </button>
      </div>
    </div>
  );
}

export default Sidebar;