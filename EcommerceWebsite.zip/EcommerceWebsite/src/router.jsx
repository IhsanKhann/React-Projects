import { createBrowserRouter } from "react-router-dom";
import LoginPage from "./LoginPage/LoginPage.jsx";
import User from "./components/User.jsx";
import Admin from "./components/Admin.jsx";
import NotFound from "./components/NotFound.jsx";

export const router = createBrowserRouter([
  {
    path: "/",
    element: <LoginPage />,
  },
  {
    path: "/user",
    element: <User />,
  },
  {
    path: "/admin",
    element: <Admin />,
  },
  {
    path: "*",
    element: <NotFound />,
  },
]);

export default router;
