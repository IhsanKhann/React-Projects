import { createSlice } from "@reduxjs/toolkit";

const sliceAdmin = createSlice({
  name: "Admin",
  initialState: { products: [] }, // ✅ Correct key name: `initialState`
  reducers: {
    setProducts: (state, action) => {
      state.products = action.payload;
    },

    addProducts: (state, action) => {
      state.products.push(action.payload);
    },

    RemoveProduct: (state, action) => {
      state.products = state.products.filter(
        (item) => item._id !== action.payload,
      );
      // Fix the remove Item
    },
    // other functions...
  },
});

export default sliceAdmin.reducer;
export const { setProducts, addProducts, RemoveProduct } = sliceAdmin.actions;