import { configureStore } from "@reduxjs/toolkit";
import sliceCartReducer from "./Slices/sliceCart";
import sliceAdminReducer from "./Slices/sliceAdmin";

const Store = configureStore({
  reducer: {
    cart: sliceCartReducer,
    admin: sliceAdminReducer,
  },
});

export default Store;
