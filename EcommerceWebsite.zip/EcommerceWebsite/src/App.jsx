import "./App.css";
import { Provider } from "react-redux";
import Store from "./store";
import { RouterProvider } from "react-router-dom";
import router from "./router";

export default function App() {
  return (
    <Provider store={Store}>
      <RouterProvider router={router} />
    </Provider>
  );
}
